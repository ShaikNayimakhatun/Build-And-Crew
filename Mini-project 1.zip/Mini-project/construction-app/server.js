const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, 'public', 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    fileFilter: function (req, file, cb) {
        if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
            return cb(new Error('Only image files are allowed!'), false);
        }
        cb(null, true);
    },
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB limit
    }
});

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Middleware
app.use(express.json());
app.use(cors());

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));
app.use('/assets', express.static(path.join(__dirname, 'public', 'assets')));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

// Initialize data arrays
let users = [];
let workers = [];
let dealers = [];
let materials = [];

// Load data from JSON files
function loadData() {
    try {
        const dataDir = path.join(__dirname, 'data');
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir);
        }

        // Load users data
        const usersPath = path.join(dataDir, 'users.json');
        if (fs.existsSync(usersPath)) {
            users = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
        } else {
            fs.writeFileSync(usersPath, JSON.stringify([]));
            users = [];
        }

        // Load workers data
        const workersPath = path.join(dataDir, 'workers.json');
        if (fs.existsSync(workersPath)) {
            workers = JSON.parse(fs.readFileSync(workersPath, 'utf8'));
        } else {
            fs.writeFileSync(workersPath, JSON.stringify([]));
            workers = [];
        }

        // Load dealers data
        const dealersPath = path.join(dataDir, 'dealers.json');
        if (fs.existsSync(dealersPath)) {
            dealers = JSON.parse(fs.readFileSync(dealersPath, 'utf8'));
        } else {
            fs.writeFileSync(dealersPath, JSON.stringify([]));
            dealers = [];
        }

        // Load materials data
        const materialsPath = path.join(dataDir, 'materials.json');
        if (fs.existsSync(materialsPath)) {
            materials = JSON.parse(fs.readFileSync(materialsPath, 'utf8'));
        } else {
            fs.writeFileSync(materialsPath, JSON.stringify([]));
            materials = [];
        }
    } catch (error) {
        console.error('Error loading data:', error);
        // Initialize empty arrays if files don't exist
        users = [];
        workers = [];
        dealers = [];
        materials = [];
    }
}

// Save data to JSON files
function saveData(filename, data) {
    try {
        const dataDir = path.join(__dirname, 'data');
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir);
        }
        fs.writeFileSync(path.join(dataDir, filename), JSON.stringify(data, null, 2));
    } catch (error) {
        console.error(`Error saving ${filename}:`, error);
        throw error;
    }
}

// Load initial data
loadData();

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access denied' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid token' });
        }
        req.user = user;
        next();
    });
};

// Middleware to verify admin token
function verifyAdminToken(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
        return res.status(401).json({ error: 'No token provided' });
    }
    
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.role !== 'admin') {
            return res.status(403).json({ error: 'Access denied' });
        }
        next();
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
}

// JWT verification middleware
const verifyToken = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        return res.status(401).json({ error: 'Access denied. No token provided.' });
    }

    try {
        const verified = jwt.verify(token, JWT_SECRET);
        req.user = verified;
        next();
    } catch (error) {
        res.status(400).json({ error: 'Invalid token' });
    }
};

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// Public API routes
app.get('/api/materials', (req, res) => {
    try {
        // Set proper JSON content type
        res.setHeader('Content-Type', 'application/json');
        
        // Check if materials array exists and is valid
        if (!Array.isArray(materials)) {
            console.error('Materials data is not an array:', materials);
            return res.status(500).json({ error: 'Invalid materials data structure' });
        }
        
        // Send the materials array as JSON
    res.json(materials);
    } catch (error) {
        console.error('Error fetching materials:', error);
        res.status(500).json({ error: 'Failed to fetch materials' });
    }
});

app.get('/api/materials/:id', (req, res) => {
    try {
        // Set proper JSON content type
        res.setHeader('Content-Type', 'application/json');
        
        const materialId = req.params.id;
        const material = materials.find(m => m.id === materialId);
        
        if (!material) {
            return res.status(404).json({ error: 'Material not found' });
        }
        
        res.json(material);
    } catch (error) {
        console.error('Error fetching material details:', error);
        res.status(500).json({ error: 'Failed to fetch material details' });
    }
});

app.get('/api/dealers', (req, res) => {
    // Remove sensitive information
    const publicDealers = dealers.map(dealer => {
        const { password, ...publicData } = dealer;
        return publicData;
    });
    res.json(publicDealers);
});

app.get('/api/workers', (req, res) => {
    try {
        // Filter for visible workers and remove sensitive information
        const publicWorkers = workers
            .filter(worker => worker.visible !== false) // Show workers unless explicitly hidden
            .map(worker => {
        const { password, ...publicData } = worker;
                return {
                    ...publicData,
                    available: worker.available !== false // Default to true if not set
                };
    });
    res.json(publicWorkers);
    } catch (error) {
        console.error('Error fetching workers:', error);
        res.status(500).json({ error: 'Failed to fetch workers' });
    }
});

app.get('/api/workers/:id', (req, res) => {
    try {
        const workerId = req.params.id;
        const worker = workers.find(w => w.id === workerId);

    if (!worker) {
        return res.status(404).json({ error: 'Worker not found' });
    }

        // Return worker data without sensitive information
        const { password, ...publicData } = worker;
        res.json({
            ...publicData,
            reviews: worker.reviews || [],
            rating: worker.rating || 0
        });
    } catch (error) {
        console.error('Error fetching worker details:', error);
        res.status(500).json({ error: 'Failed to fetch worker details' });
    }
});

// Protected API routes (Admin and Dealer)
app.post('/api/materials', verifyToken, upload.single('image'), (req, res) => {
    try {
        console.log('[MATERIAL] Request received for adding material');
        console.log('[MATERIAL] User role:', req.user.role);
        // Only allow admins and dealers to add materials
        if (req.user.role !== 'admin' && req.user.role !== 'dealer') {
            if (req.file) {
                fs.unlinkSync(req.file.path);
            }
            return res.status(403).json({ error: 'Access denied. Only dealers and admins can add materials.' });
        }
        // Validate required fields
        const requiredFields = ['name', 'category', 'price', 'unit', 'description', 'supplier'];
        for (const field of requiredFields) {
            if (!req.body[field]) {
                if (req.file) {
                    fs.unlinkSync(req.file.path);
                }
                console.log('[MATERIAL] Missing required field:', field);
                return res.status(400).json({ error: `Missing required field: ${field}` });
            }
        }
        const newMaterial = {
            id: Date.now().toString(),
            name: req.body.name,
            category: req.body.category,
            price: parseFloat(req.body.price),
            unit: req.body.unit,
            description: req.body.description,
            inStock: req.body.inStock === 'true',
            supplier: req.body.supplier,
            dealerId: req.user.id,
            image: req.file ? '/uploads/' + req.file.filename : '/assets/images/placeholder.jpg'
        };
        materials.push(newMaterial);
        saveData('materials.json', materials);
        console.log('[MATERIAL] Material added:', newMaterial.name, 'by', req.user.role);
        res.json(newMaterial);
    } catch (error) {
        console.error('[MATERIAL] Error adding material:', error);
        if (req.file) {
            try {
                fs.unlinkSync(req.file.path);
            } catch (unlinkError) {
                console.error('Error deleting uploaded file:', unlinkError);
            }
        }
        res.status(500).json({ error: 'Failed to add material: ' + error.message });
    }
});

app.post('/api/dealers', verifyAdminToken, (req, res) => {
    const newDealer = {
        id: Date.now().toString(),
        ...req.body
    };
    dealers.push(newDealer);
    saveData('dealers.json', dealers);
    res.json(newDealer);
});

app.post('/api/workers', verifyAdminToken, (req, res) => {
    const newWorker = {
        id: Date.now().toString(),
        ...req.body
    };
    workers.push(newWorker);
    saveData('workers.json', workers);
    res.json(newWorker);
});

// Registration endpoint with debug logging
app.post('/api/register', (req, res) => {
    const { username, password, firstName, lastName, email, phone, role, company, address } = req.body;
    if (!username || !password || !firstName || !lastName || !email || !phone || !role) {
        console.log('[REGISTER] Missing required fields');
            return res.status(400).json({ error: 'All required fields must be filled' });
        }
    // Check if username already exists
        if (users.some(u => u.username === username) || 
            workers.some(w => w.username === username) || 
            dealers.some(d => d.username === username)) {
        console.log('[REGISTER] Username already exists:', username);
            return res.status(400).json({ error: 'Username already exists' });
        }
    const hashedPassword = bcrypt.hashSync(password, 10);
        const newUser = {
            id: Date.now().toString(),
        username,
        password: hashedPassword,
        firstName,
        lastName,
        email,
        phone,
        role,
        company: company || '',
        address: address || '',
        createdAt: new Date().toISOString()
    };
    users.push(newUser);
    saveData('users.json', users);
    console.log('[REGISTER] Added user:', username, 'role:', role);
    // If dealer, also add to dealers.json
    if (role === 'dealer') {
        const newDealer = {
            id: newUser.id,
            username,
            password: hashedPassword,
            firstName,
            lastName,
            email,
            phone,
            role,
            company: company || '',
            address: address || '',
            createdAt: newUser.createdAt
        };
        dealers.push(newDealer);
            saveData('dealers.json', dealers);
        console.log('[REGISTER] Also added to dealers.json:', username);
    }
    const token = jwt.sign({ id: newUser.id, role: newUser.role }, JWT_SECRET, { expiresIn: '1h' });
    res.status(201).json({ token });
});

// Login endpoint with clear file-based logic
app.post('/api/login', (req, res) => {
    try {
        const { username, password, role } = req.body;
        
        if (!username || !password || !role) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        let user;
        if (role === 'worker') {
            user = workers.find(w => w.username === username);
            if (!user) {
                console.log('[LOGIN] Worker not found:', username);
                return res.status(400).json({ error: 'Worker not found' });
            }
        } else if (role === 'dealer') {
            user = dealers.find(d => d.username === username);
            if (!user) {
                console.log('[LOGIN] Dealer not found:', username);
                return res.status(400).json({ error: 'Dealer not found' });
            }
        } else {
            user = users.find(u => u.username === username);
        if (!user) {
                console.log('[LOGIN] User not found:', username);
            return res.status(400).json({ error: 'User not found' });
            }
        }

        const validPassword = bcrypt.compareSync(password, user.password);
        if (!validPassword) {
            console.log('[LOGIN] Invalid password for:', username);
            return res.status(400).json({ error: 'Invalid password' });
        }

        const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1h' });
        return res.json({ 
            token,
                username: user.username,
                role: user.role
        });
    } catch (error) {
        console.error('[LOGIN] Error:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
});

// Dealer profile endpoint
app.get('/api/dealer/profile', verifyToken, async (req, res) => {
    try {
        // Find the dealer by ID from the token
        const dealer = dealers.find(d => d.id === req.user.id);
        if (!dealer) {
            return res.status(404).json({ error: 'Dealer not found' });
        }

        // Return dealer data without sensitive information
        const { password, ...dealerProfile } = dealer;
        res.json({
            id: dealerProfile.id,
            name: `${dealerProfile.firstName} ${dealerProfile.lastName}`,
            company: dealerProfile.company,
            email: dealerProfile.email,
            phone: dealerProfile.phone
        });
    } catch (error) {
        console.error('Error fetching dealer profile:', error);
        res.status(500).json({ error: 'Failed to fetch dealer profile' });
    }
});

// Add material endpoint
app.post('/api/materials', authenticateToken, upload.single('image'), (req, res) => {
    try {
        const dealer = dealers.find(d => d.id === req.user.id);
        if (!dealer) {
            return res.status(404).json({ error: 'Dealer not found' });
        }

        const { name, category, price, unit, description } = req.body;
        const imagePath = req.file ? `/uploads/${req.file.filename}` : null;

        const newMaterial = {
            id: Date.now().toString(),
            name,
            category,
            price: parseFloat(price),
            unit,
            description,
            image: imagePath,
            supplier: dealer.company,
            inStock: true,
            createdAt: new Date().toISOString()
        };

        materials.push(newMaterial);
        saveData('materials.json', materials);

        res.status(201).json(newMaterial);
    } catch (error) {
        console.error('Error adding material:', error);
        res.status(500).json({ error: 'Failed to add material' });
    }
});

// Worker Profile and Dashboard Routes
app.post('/api/bookings', verifyToken, async (req, res) => {
    try {
        console.log('Booking request received:', req.body);
        const { workerId, date, projectDetails, address, name, contact } = req.body;
        
        // Validate required fields
        if (!workerId || !date || !projectDetails || !address) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const userId = req.user.id;
        console.log('User ID:', userId);

        // Read existing users data
        const usersPath = path.join(__dirname, 'data', 'users.json');
        let users = [];
        
        try {
            if (fs.existsSync(usersPath)) {
                const data = await fs.promises.readFile(usersPath, 'utf8');
                users = JSON.parse(data);
                console.log('Users data loaded:', users.length, 'users found');
            } else {
                console.log('Users file not found');
                return res.status(500).json({ error: 'Users data file not found' });
            }
        } catch (error) {
            console.error('Error reading users file:', error);
            return res.status(500).json({ error: 'Failed to read users data' });
        }

        // Find user
        const userIndex = users.findIndex(u => u.id === userId);
        console.log('User index:', userIndex);
        if (userIndex === -1) {
            console.log('User not found with ID:', userId);
            return res.status(404).json({ error: 'User not found' });
        }

        // Initialize selectedWorkers array if it doesn't exist
        if (!users[userIndex].selectedWorkers) {
            console.log('Initializing selectedWorkers array');
            users[userIndex].selectedWorkers = [];
        }

        // Add new booking
        const newBooking = {
            workerId,
            date,
            projectDetails,
            address,
            name: name || 'Anonymous',
            contact: contact || 'Not provided',
            status: 'pending'
        };
        console.log('Adding new booking:', newBooking);
        users[userIndex].selectedWorkers.push(newBooking);

        // Save updated data
        try {
            await fs.promises.writeFile(usersPath, JSON.stringify(users, null, 2));
            console.log('Booking saved successfully');
            return res.json({ message: 'Booking created successfully' });
        } catch (error) {
            console.error('Error saving booking:', error);
            return res.status(500).json({ error: 'Failed to save booking data' });
        }
    } catch (error) {
        console.error('Error creating booking:', error);
        return res.status(500).json({ error: 'Failed to create booking: ' + error.message });
    }
});

app.get('/api/worker/profile', verifyToken, async (req, res) => {
    try {
        // Check if the user is a worker
        if (req.user.role !== 'worker') {
            return res.status(403).json({ error: 'Access denied. Only workers can access this endpoint.' });
        }

        // Find the worker by ID
        const worker = workers.find(w => w.id === req.user.id);
        if (!worker) {
            return res.status(404).json({ error: 'Worker not found' });
        }

        // Get worker's bookings
        const workerBookings = users.reduce((bookings, user) => {
            if (user.selectedWorkers) {
                const workerBookings = user.selectedWorkers.filter(booking => booking.workerId === worker.id);
                bookings.push(...workerBookings);
            }
            return bookings;
        }, []);

        // Return worker data without sensitive information
        const { password, ...workerData } = worker;
        res.json({
            ...workerData,
            bookings: workerBookings
        });
    } catch (error) {
        console.error('[WORKER] Error fetching worker profile:', error);
        res.status(500).json({ error: 'Failed to fetch worker profile' });
    }
});

// Edit material endpoint
app.put('/api/materials/:id', verifyToken, upload.single('image'), async (req, res) => {
    try {
        const materialId = req.params.id;
        const materialIndex = materials.findIndex(m => m.id === materialId);
        
        if (materialIndex === -1) {
            return res.status(404).json({ error: 'Material not found' });
        }

        // Check if the dealer owns this material
        const dealer = dealers.find(d => d.id === req.user.id);
        if (!dealer || materials[materialIndex].supplier !== dealer.company) {
            return res.status(403).json({ error: 'Not authorized to edit this material' });
        }

        // Update material data
        const updatedMaterial = {
            ...materials[materialIndex],
            name: req.body.name || materials[materialIndex].name,
            category: req.body.category || materials[materialIndex].category,
            price: parseFloat(req.body.price) || materials[materialIndex].price,
            unit: req.body.unit || materials[materialIndex].unit,
            description: req.body.description || materials[materialIndex].description,
            inStock: req.body.inStock === 'true',
            image: req.file ? `/uploads/${req.file.filename}` : materials[materialIndex].image
        };

        materials[materialIndex] = updatedMaterial;
        saveData('materials.json', materials);
        
        // Return the updated material
        return res.status(200).json(updatedMaterial);
    } catch (error) {
        console.error('Error updating material:', error);
        return res.status(500).json({ error: 'Failed to update material' });
    }
});

// Worker availability endpoint
app.patch('/api/worker/availability', verifyToken, async (req, res) => {
    try {
        // Check if the user is a worker
        if (req.user.role !== 'worker') {
            return res.status(403).json({ error: 'Access denied. Only workers can update their availability.' });
        }

        const { available } = req.body;
        if (typeof available !== 'boolean') {
            return res.status(400).json({ error: 'Invalid availability status' });
        }

        // Find the worker
        const workerIndex = workers.findIndex(w => w.id === req.user.id);
        if (workerIndex === -1) {
            return res.status(404).json({ error: 'Worker not found' });
        }

        // Update availability
        workers[workerIndex].available = available;
        workers[workerIndex].updatedAt = new Date().toISOString();
        
        // Save changes
        saveData('workers.json', workers);

        res.json({ 
            message: 'Availability updated successfully',
            available 
        });
    } catch (error) {
        console.error('[WORKER] Error updating availability:', error);
        res.status(500).json({ error: 'Failed to update availability' });
    }
});

// Get material details with all dealers who have it
app.get('/api/materials/:id', (req, res) => {
    try {
        const materialId = req.params.id;
        console.log('Looking for material with ID:', materialId);
        
        const material = materials.find(m => {
            const currentId = m.id ? m.id.toString() : '';
            const searchId = materialId.toString();
            console.log('Checking material ID:', currentId, 'against:', searchId);
            return currentId === searchId;
        });
        
        if (!material) {
            console.log('Material not found with ID:', materialId);
            return res.status(404).json({ error: 'Material not found' });
        }

        console.log('Found material:', material);

        // Find all dealers who have this material
        const dealersWithMaterial = dealers.filter(d => {
            const dealerMaterials = d.materials || [];
            return dealerMaterials.includes(materialId.toString());
        });

        console.log('Found dealers with material:', dealersWithMaterial.length);

        // Format dealer information
        const dealerInfo = dealersWithMaterial.map(dealer => ({
            id: dealer.id,
            name: dealer.name || 
                 (dealer.firstName && dealer.lastName ? `${dealer.firstName} ${dealer.lastName}` : '') || 
                 'Not specified',
            company: dealer.company || 'Not specified',
            email: dealer.email || 'Not specified',
            phone: dealer.phone || dealer.contact || 'Not specified',
            address: dealer.address || dealer.location || 'Not specified',
            price: material.price || 0,
            inStock: material.inStock !== undefined ? material.inStock : true
        }));

        // Clean up any undefined or null values
        dealerInfo.forEach(dealer => {
            Object.keys(dealer).forEach(key => {
                if (dealer[key] === undefined || dealer[key] === null) {
                    dealer[key] = 'Not specified';
                }
            });
        });

        console.log('Returning material with dealers:', {
            ...material,
            dealers: dealerInfo
        });

        // Return material with all dealers who have it
        res.json({
            ...material,
            dealers: dealerInfo
        });
    } catch (error) {
        console.error('[MATERIAL] Error fetching material details:', error);
        res.status(500).json({ error: 'Failed to fetch material details' });
    }
});

app.get('/api/dealers/:id', (req, res) => {
    try {
        const dealerId = req.params.id;
        console.log('Looking for dealer with ID:', dealerId);
        
        // Find dealer by ID (handle both string and number IDs)
        const dealer = dealers.find(d => {
            const currentId = d.id ? d.id.toString() : '';
            const searchId = dealerId.toString();
            console.log('Checking dealer ID:', currentId, 'against:', searchId);
            return currentId === searchId;
        });
        
        if (!dealer) {
            console.log('Dealer not found with ID:', dealerId);
            return res.status(404).json({ error: 'Dealer not found' });
        }

        console.log('Found dealer:', dealer);

        // Handle both types of dealer entries
        const dealerData = {
            id: dealer.id,
            name: dealer.name || 
                 (dealer.firstName && dealer.lastName ? `${dealer.firstName} ${dealer.lastName}` : '') || 
                 'Not specified',
            company: dealer.company || 'Not specified',
            email: dealer.email || 'Not specified',
            phone: dealer.phone || dealer.contact || 'Not specified',
            address: dealer.address || dealer.location || 'Not specified',
            workingHours: dealer.workingHours || 'Not specified',
            rating: dealer.rating || 'Not rated',
            materials: dealer.materials || []
        };

        // Clean up any undefined or null values
        Object.keys(dealerData).forEach(key => {
            if (dealerData[key] === undefined || dealerData[key] === null) {
                dealerData[key] = 'Not specified';
            }
        });

        console.log('Returning dealer data:', dealerData);
        res.json(dealerData);
    } catch (error) {
        console.error('[DEALER] Error fetching dealer details:', error);
        res.status(500).json({ error: 'Failed to fetch dealer details' });
    }
});

// Delete material endpoint
app.delete('/api/materials/:id', verifyToken, (req, res) => {
    try {
        const materialId = req.params.id;
        const materialIndex = materials.findIndex(m => m.id === materialId);

        if (materialIndex === -1) {
            return res.status(404).json({ error: 'Material not found' });
        }

        // Only allow the dealer who owns the material or an admin to delete
        const material = materials[materialIndex];
        if (req.user.role !== 'admin' && material.dealerId !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized to delete this material' });
        }

        materials.splice(materialIndex, 1);
        saveData('materials.json', materials);

        res.json({ message: 'Material deleted successfully' });
    } catch (error) {
        console.error('Error deleting material:', error);
        res.status(500).json({ error: 'Failed to delete material' });
    }
});

// Add review endpoint
app.post('/api/reviews', verifyToken, async (req, res) => {
    try {
        const { itemId, itemType, rating, text } = req.body;
        
        if (!itemId || !itemType || !rating || !text) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        // Get user information
        const user = users.find(u => u.id === req.user.id);
    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

        const review = {
            id: Date.now().toString(),
            userId: user.id,
            userName: user.username,
            rating: parseInt(rating),
            text,
            date: new Date().toISOString()
        };

        // Add review based on item type
        if (itemType === 'material') {
            const materialIndex = materials.findIndex(m => m.id === itemId);
            if (materialIndex === -1) {
                return res.status(404).json({ error: 'Material not found' });
            }

            // Initialize reviews array if it doesn't exist
            if (!materials[materialIndex].reviews) {
                materials[materialIndex].reviews = [];
            }

            // Add the review
            materials[materialIndex].reviews.push(review);

            // Update average rating
            const avgRating = materials[materialIndex].reviews.reduce((sum, r) => sum + r.rating, 0) 
                            / materials[materialIndex].reviews.length;
            materials[materialIndex].rating = parseFloat(avgRating.toFixed(1));

            // Save updated materials data
            saveData('materials.json', materials);
        } else if (itemType === 'worker') {
            const workerIndex = workers.findIndex(w => w.id === itemId);
            if (workerIndex === -1) {
                return res.status(404).json({ error: 'Worker not found' });
            }

            // Initialize reviews array if it doesn't exist
            if (!workers[workerIndex].reviews) {
                workers[workerIndex].reviews = [];
            }

            // Add the review
            workers[workerIndex].reviews.push(review);

            // Update average rating
            const avgRating = workers[workerIndex].reviews.reduce((sum, r) => sum + r.rating, 0) 
                            / workers[workerIndex].reviews.length;
            workers[workerIndex].rating = parseFloat(avgRating.toFixed(1));

            // Save updated workers data
            saveData('workers.json', workers);
        }

        res.status(201).json({ message: 'Review added successfully', review });
    } catch (error) {
        console.error('Error adding review:', error);
        res.status(500).json({ error: 'Failed to add review' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
}); 