# Construction Marketplace

A web application that helps users find construction materials from local dealers and connect with skilled construction workers in their area.

## Features

- Search for construction materials
- Find nearby material dealers
- View material prices and dealer contact information
- Search for skilled workers by expertise
- View worker profiles, experience, and hourly rates
- Contact workers directly
- Rating system for both dealers and workers

## Prerequisites

- Node.js (v14 or higher)
- MongoDB
- npm or yarn

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd construction-marketplace
```

2. Install backend dependencies:
```bash
npm install
```

3. Install frontend dependencies:
```bash
cd client
npm install
cd ..
```

4. Create a `.env` file in the root directory with the following content:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/construction-marketplace
JWT_SECRET=your_jwt_secret_key_here
```

## Running the Application

1. Start MongoDB service on your machine

2. Run the development server (both frontend and backend):
```bash
npm run dev:full
```

This will start:
- Backend server on http://localhost:5000
- Frontend development server on http://localhost:3000

## API Endpoints

### Materials
- GET `/api/materials` - Get all materials
- GET `/api/materials/:id` - Get material by ID
- POST `/api/materials` - Create new material

### Dealers
- GET `/api/dealers` - Get all dealers
- GET `/api/dealers/nearby` - Get nearby dealers
- GET `/api/dealers/:id` - Get dealer by ID
- POST `/api/dealers` - Create new dealer
- POST `/api/dealers/:id/ratings` - Add rating to dealer

### Workers
- GET `/api/workers` - Get all workers
- GET `/api/workers/nearby` - Get nearby workers
- GET `/api/workers/:id` - Get worker by ID
- POST `/api/workers` - Create new worker
- POST `/api/workers/:id/ratings` - Add rating to worker
- PATCH `/api/workers/:id/availability` - Update worker availability

## Technologies Used

- Frontend:
  - React
  - TypeScript
  - Material-UI
  - Axios
  - React Router

- Backend:
  - Node.js
  - Express
  - JWT for authentication
  - CORS 